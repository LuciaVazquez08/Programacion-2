class Vehicle:
    def start_engine(self):
        pass

    def stop_engine(self):
        pass

    def get_vehicle_type(self):
        pass
