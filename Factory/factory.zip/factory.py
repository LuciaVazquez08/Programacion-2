from abc import ABC

class VehicleCreator(ABC):
    def create_vehicle(self):
        pass